import { CodeFile, SimilarityResult, BatchCompareRequest, SupportedLanguage, PaginationParams } from '../types';

// Mock data storage using localStorage
const STORAGE_KEY = 'plagiarism_checker_files';

// Helper function to get files from localStorage
const getStoredFiles = (): CodeFile[] => {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch {
    return [];
  }
};

// Helper function to save files to localStorage
const saveStoredFiles = (files: CodeFile[]): void => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(files));
  } catch (error) {
    console.error('Failed to save files to localStorage:', error);
  }
};

// Generate a simple similarity score based on file names and content length
const calculateSimilarity = (file1: CodeFile, file2: CodeFile): number => {
  // Simple mock similarity calculation
  const nameSimilarity = file1.fileName === file2.fileName ? 0.5 : 0;
  const sizeDifference = Math.abs(file1.size - file2.size);
  const sizeSimilarity = Math.max(0, 1 - sizeDifference / Math.max(file1.size, file2.size));
  return Math.min(1, nameSimilarity + sizeSimilarity * 0.5) * 100;
};

// Mock delay to simulate network requests
const mockDelay = (ms: number = 500): Promise<void> => 
  new Promise(resolve => setTimeout(resolve, ms));

// Single file upload
export const uploadFile = async (file: File, language: SupportedLanguage): Promise<CodeFile> => {
  await mockDelay();
  
  const files = getStoredFiles();
  const newFile: CodeFile = {
    id: Date.now(),
    fileName: file.name,
    language,
    size: file.size,
    createdAt: new Date().toISOString(),
    content: await file.text(),
  };
  
  const updatedFiles = [newFile, ...files];
  saveStoredFiles(updatedFiles);
  
  return newFile;
};

// Batch file upload
export const uploadBatchFiles = async (files: File[], language: SupportedLanguage): Promise<CodeFile[]> => {
  await mockDelay(1000);
  
  const storedFiles = getStoredFiles();
  const newFiles: CodeFile[] = [];
  
  for (const file of files) {
    const newFile: CodeFile = {
      id: Date.now() + Math.random(),
      fileName: file.name,
      language,
      size: file.size,
      createdAt: new Date().toISOString(),
      content: await file.text(),
    };
    newFiles.push(newFile);
  }
  
  const updatedFiles = [...newFiles, ...storedFiles];
  saveStoredFiles(updatedFiles);
  
  return newFiles;
};

// Compare two files
export const compareFiles = async (fileId1: number, fileId2: number): Promise<number> => {
  await mockDelay();
  
  const files = getStoredFiles();
  const file1 = files.find(f => f.id === fileId1);
  const file2 = files.find(f => f.id === fileId2);
  
  if (!file1 || !file2) {
    throw new Error('One or both files not found');
  }
  
  return calculateSimilarity(file1, file2);
};

// Compare file against all others
export const compareAgainstAll = async (
  fileId: number, 
  params: PaginationParams
): Promise<{ content: SimilarityResult[]; totalElements: number; totalPages: number }> => {
  await mockDelay(800);
  
  const files = getStoredFiles();
  const targetFile = files.find(f => f.id === fileId);
  
  if (!targetFile) {
    throw new Error('Target file not found');
  }
  
  const otherFiles = files.filter(f => f.id !== fileId);
  const results: SimilarityResult[] = otherFiles.map(file => ({
    file1: targetFile,
    file2: file,
    similarity: calculateSimilarity(targetFile, file),
  }));
  
  // Sort by similarity (highest first)
  results.sort((a, b) => b.similarity - a.similarity);
  
  // Apply pagination
  const page = params.page || 0;
  const size = params.size || 10;
  const startIndex = page * size;
  const endIndex = startIndex + size;
  const paginatedResults = results.slice(startIndex, endIndex);
  
  return {
    content: paginatedResults,
    totalElements: results.length,
    totalPages: Math.ceil(results.length / size),
  };
};

// Batch compare files
export const compareBatchFiles = async (request: BatchCompareRequest): Promise<SimilarityResult[]> => {
  await mockDelay(1200);
  
  const files = getStoredFiles();
  const results: SimilarityResult[] = [];
  
  for (const pair of request.filePairs) {
    const file1 = files.find(f => f.id === pair.fileId1);
    const file2 = files.find(f => f.id === pair.fileId2);
    
    if (file1 && file2) {
      results.push({
        file1,
        file2,
        similarity: calculateSimilarity(file1, file2),
      });
    }
  }
  
  return results;
};

// Get all files
export const getAllFiles = async (): Promise<CodeFile[]> => {
  await mockDelay(300);
  
  const files = getStoredFiles();
  
  // If no files exist, create some sample files
  if (files.length === 0) {
    const sampleFiles: CodeFile[] = [
      {
        id: 1,
        fileName: 'example1.js',
        language: 'JAVASCRIPT',
        size: 1024,
        createdAt: new Date(Date.now() - 86400000).toISOString(), // 1 day ago
        content: 'function hello() {\n  console.log("Hello World!");\n}',
      },
      {
        id: 2,
        fileName: 'example2.py',
        language: 'PYTHON',
        size: 512,
        createdAt: new Date(Date.now() - 43200000).toISOString(), // 12 hours ago
        content: 'def hello():\n    print("Hello World!")',
      },
      {
        id: 3,
        fileName: 'example3.java',
        language: 'JAVA',
        size: 2048,
        createdAt: new Date().toISOString(),
        content: 'public class Hello {\n    public static void main(String[] args) {\n        System.out.println("Hello World!");\n    }\n}',
      },
    ];
    
    saveStoredFiles(sampleFiles);
    return sampleFiles;
  }
  
  return files;
};